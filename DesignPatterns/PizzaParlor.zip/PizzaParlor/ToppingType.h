#ifndef TOPPING_TYPE_H
#define TOPPING_TYPE_H

#include <string>
#include <vector>
#include <list>
#include <iostream>
#include <assert.h>

enum ToppingType
{
    CHEESE,
    HAM,
    PEPPERONI,
    GREEN_PEPPER,
    ONIONS,
    MUSHROOMS,
    PINEAPPLE
};

#endif
